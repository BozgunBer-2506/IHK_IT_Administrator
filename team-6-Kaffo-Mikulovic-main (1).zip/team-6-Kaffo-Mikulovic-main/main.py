from fastapi import FastAPI, HTTPException, Depends, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from database import FilmDB, get_db, init_db
from models import Film, FilmEingabe, Bewertung

app = FastAPI(
    title="Film-Bewertungs-API",
    description="API zum Verwalten und Bewerten von Action- und Comedy-Filmen",
    version="1.0.0"
)

app.openapi_tags = [
    {"name": "Filme", "description": "CRUD-Operationen für Filme"},
    {"name": "Statistik", "description": "Auswertungen & Statistiken"}
]


@app.on_event("startup")
def startup_event():
    init_db()
    from database import SessionLocal
    
    db = SessionLocal()
    try:
        if db.query(FilmDB).count() == 0:
            beispiel_filme = [
                FilmDB(titel="Die Hard", regisseur="John McTiernan", erscheinungsjahr=1988, kategorie="action", bewertung=8.2, anzahl_bewertungen=1),
                FilmDB(titel="The Avengers", regisseur="Joss Whedon", erscheinungsjahr=2012, kategorie="action", bewertung=8.0, anzahl_bewertungen=1),
                FilmDB(titel="Superbad", regisseur="Greg Mottola", erscheinungsjahr=2007, kategorie="comedy", bewertung=7.6, anzahl_bewertungen=1),
                FilmDB(titel="The Hangover", regisseur="Todd Phillips", erscheinungsjahr=2009, kategorie="comedy", bewertung=7.7, anzahl_bewertungen=1)
            ]
            db.add_all(beispiel_filme)
            db.commit()
    finally:
        db.close()

@app.get("/")
def startseite():
    return {
        "nachricht": "Willkommen zur Film-Bewertungs-API",
        "version": "1.0.0",
        "dokumentation": "/docs",
        "kategorien": ["action", "comedy"]
    }

@app.get("/filme", response_model=List[Film])
def alle_filme_abrufen(db: Session = Depends(get_db), kategorie: Optional[str] = Query(None)):
    if kategorie:
        if kategorie not in ["action", "comedy"]:
            raise HTTPException(status_code=400, detail="Kategorie muss 'action' oder 'comedy' sein")
        return db.query(FilmDB).filter(FilmDB.kategorie == kategorie).all()
    return db.query(FilmDB).all()

@app.get("/filme/action", response_model=List[Film])
def action_filme_abrufen(db: Session = Depends(get_db)):
    return db.query(FilmDB).filter(FilmDB.kategorie == "action").all()

@app.get("/filme/comedy", response_model=List[Film])
def comedy_filme_abrufen(db: Session = Depends(get_db)):
    return db.query(FilmDB).filter(FilmDB.kategorie == "comedy").all()

@app.get("/filme/{film_id}", response_model=Film)
def film_nach_id_abrufen(film_id: int, db: Session = Depends(get_db)):
    film = db.query(FilmDB).filter(FilmDB.id == film_id).first()
    if not film:
        raise HTTPException(status_code=404, detail=f"Film mit ID {film_id} nicht gefunden")
    return film

@app.get("/filme/suchen/", response_model=List[Film])
def filme_suchen(titel: str = Query(..., min_length=1), db: Session = Depends(get_db)):
    filme = db.query(FilmDB).filter(FilmDB.titel.contains(titel)).all()
    if not filme:
        raise HTTPException(status_code=404, detail=f"Keine Filme mit '{titel}' gefunden")
    return filme

@app.post("/filme", response_model=Film, status_code=201)
def film_hinzufuegen(film: FilmEingabe, db: Session = Depends(get_db)):
    existierender_film = db.query(FilmDB).filter(FilmDB.titel == film.titel, FilmDB.erscheinungsjahr == film.erscheinungsjahr).first()
    if existierender_film:
        raise HTTPException(status_code=400, detail=f"Film '{film.titel}' existiert bereits")
    neuer_film = FilmDB(titel=film.titel, regisseur=film.regisseur, erscheinungsjahr=film.erscheinungsjahr, kategorie=film.kategorie, bewertung=0.0, anzahl_bewertungen=0)
    db.add(neuer_film)
    db.commit()
    db.refresh(neuer_film)
    return neuer_film

@app.post("/filme/{film_id}/bewerten", response_model=Film)
def film_bewerten(film_id: int, bewertung: Bewertung, db: Session = Depends(get_db)):
    film = db.query(FilmDB).filter(FilmDB.id == film_id).first()
    if not film:
        raise HTTPException(status_code=404, detail=f"Film mit ID {film_id} nicht gefunden")
    gesamtbewertung = (film.bewertung * film.anzahl_bewertungen) + bewertung.bewertung
    film.anzahl_bewertungen += 1
    film.bewertung = round(gesamtbewertung / film.anzahl_bewertungen, 1)
    db.commit()
    db.refresh(film)
    return film

@app.delete("/filme/{film_id}", status_code=204)
def film_loeschen(film_id: int, db: Session = Depends(get_db)):
    film = db.query(FilmDB).filter(FilmDB.id == film_id).first()
    if not film:
        raise HTTPException(status_code=404, detail=f"Film mit ID {film_id} nicht gefunden")
    db.delete(film)
    db.commit()

@app.get("/statistik")
def statistik_abrufen(db: Session = Depends(get_db)):
    gesamt_filme = db.query(FilmDB).count()
    action_filme = db.query(FilmDB).filter(FilmDB.kategorie == "action").count()
    comedy_filme = db.query(FilmDB).filter(FilmDB.kategorie == "comedy").count()
    alle_filme = db.query(FilmDB).all()
    
    if alle_filme:
        durchschnitt_gesamt = round(sum(f.bewertung for f in alle_filme) / len(alle_filme), 1)
        action_bewertungen = [f.bewertung for f in alle_filme if f.kategorie == "action"]
        durchschnitt_action = round(sum(action_bewertungen) / len(action_bewertungen), 1) if action_bewertungen else 0.0
        comedy_bewertungen = [f.bewertung for f in alle_filme if f.kategorie == "comedy"]
        durchschnitt_comedy = round(sum(comedy_bewertungen) / len(comedy_bewertungen), 1) if comedy_bewertungen else 0.0
        top_filme = sorted(alle_filme, key=lambda x: x.bewertung, reverse=True)[:3]
        top_3 = [{"id": f.id, "titel": f.titel, "bewertung": f.bewertung} for f in top_filme]
    else:
        durchschnitt_gesamt = durchschnitt_action = durchschnitt_comedy = 0.0
        top_3 = []
    
    return {
        "gesamtanzahl_filme": gesamt_filme,
        "anzahl_action_filme": action_filme,
        "anzahl_comedy_filme": comedy_filme,
        "durchschnittsbewertung_gesamt": durchschnitt_gesamt,
        "durchschnittsbewertung_action": durchschnitt_action,
        "durchschnittsbewertung_comedy": durchschnitt_comedy,
        "top_3_filme": top_3
    }



