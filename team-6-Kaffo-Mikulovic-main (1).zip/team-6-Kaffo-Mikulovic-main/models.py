from pydantic import BaseModel, Field
from typing import Literal

# Modell für Film-Eingabe
class FilmEingabe(BaseModel):
    titel: str = Field(..., min_length=1, description="Titel des Films")
    regisseur: str = Field(..., min_length=1, description="Regisseur des Films")
    erscheinungsjahr: int = Field(..., ge=1900, le=2030, description="Erscheinungsjahr")
    kategorie: Literal["action", "comedy"] = Field(..., description="Filmkategorie")
    
    class Config:
        json_schema_extra = {
            "example": {
                "titel": "Die Hard",
                "regisseur": "John McTiernan",
                "erscheinungsjahr": 1988,
                "kategorie": "action"
            }
        }

# Modell für Film-Antwort (mit ID und Bewertung)
class Film(FilmEingabe):
    id: int
    bewertung: float = 0.0
    anzahl_bewertungen: int = 0
    
    class Config:
        from_attributes = True

# Modell für Bewertung
class Bewertung(BaseModel):
    bewertung: float = Field(..., ge=0.0, le=10.0, description="Bewertung von 0 bis 10")
    
    class Config:
        json_schema_extra = {
            "example": {
                "bewertung": 8.5
            }
        }
        