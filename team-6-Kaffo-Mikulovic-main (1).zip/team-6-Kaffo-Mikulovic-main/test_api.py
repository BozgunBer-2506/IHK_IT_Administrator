"""Tests für die API"""
from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def test_root():
    """Test des Root-Endpoints"""
    response = client.get("/")
    assert response.status_code == 200
    print("\n✓ Root-Endpoint funktioniert!")

def test_filme_liste():
    """Test der Filmliste"""
    response = client.get("/filme")
    assert response.status_code == 200
    print("\n✓ Filmliste abgerufen!")

def test_statistiques():
    """Test des Statistik-Endpoints"""
    response = client.get("/statistiques")
    assert response.status_code == 200
    data = response.json()
    assert "total_livres" in data
    print(f"\n✓ Test erfolgreich: {data}")

def test_docs():
    """Test der Dokumentation"""
    response = client.get("/docs")
    assert response.status_code == 200
    print("\n✓ Dokumentation OK!")

def test_film_hinzufuegen():
    """Test zum Hinzufügen eines Films"""
    neuer_film = {
        "titel": "Testfilm",
        "regisseur": "Test Regisseur",
        "erscheinungsjahr": 2024,
        "kategorie": "action",
        "bewertung": 8.5
    }
    response = client.post("/filme", json=neuer_film)
    assert response.status_code in [200, 201, 400]
    print("\n✓ Film erfolgreich hinzugefügt!")

def test_film_einzeln():
    """Test zum Abrufen eines einzelnen Films"""
    response = client.get("/filme/1")
    assert response.status_code in [200, 404]
    print("\n✓ Film-Abruf funktioniert!")

def test_film_loeschen():
    """Test zum Löschen eines Films"""
    response = client.delete("/filme/1")
    assert response.status_code in [200, 204, 404]
    print("\n✓ Film-Löschung funktioniert!")

def test_film_aktualisieren():
    """Test zum Aktualisieren eines Films"""
    updated_film = {
        "titel": "Aktualisierter Film",
        "bewertung": 9.0
    }
    response = client.put("/filme/1", json=updated_film)
    assert response.status_code in [200, 404, 405]
    print("\n✓ Film-Aktualisierung funktioniert!")

