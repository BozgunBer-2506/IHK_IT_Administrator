from sqlalchemy import create_engine, Column, Integer, String, Float
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

# SQLite-Datenbank-URL
SQLALCHEMY_DATABASE_URL = "sqlite:///./filme.db"

# Engine erstellen
engine = create_engine(
    SQLALCHEMY_DATABASE_URL,
    connect_args={"check_same_thread": False}
)

# Session erstellen
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Basisklasse für Modelle
Base = declarative_base()

# Datenbank-Modell für Filme
class FilmDB(Base):
    __tablename__ = "filme"
    
    id = Column(Integer, primary_key=True, index=True)
    titel = Column(String, index=True, nullable=False)
    regisseur = Column(String)
    erscheinungsjahr = Column(Integer)
    kategorie = Column(String, nullable=False)  # "action" oder "comedy"
    bewertung = Column(Float, default=0.0)  # Bewertung von 0-10
    anzahl_bewertungen = Column(Integer, default=0)

# Tabellen erstellen
def init_db():
    Base.metadata.create_all(bind=engine)

# Datenbank-Session abrufen
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
        